function gusto() {
    alert("Que bueno que te alla gustado");
}
function NoLeGusto() {
    alert("Me vale");
}
function Hora(){
    document.getElementById('lahora').innerHTML = Date();
}
function Recargar(){
    location.reload();
}