package CONTROLADOR;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import MODELO.Usuario;
import model.dao.DAO_Usuario;


@WebServlet(name = "CrearUsuarioServlet", urlPatterns = {"/CrearUsuarioServlet"})
public class CrearUsuarioServlet extends HttpServlet {

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        try {
            Usuario usu = new Usuario();
            
            usu.setCorreo(request.getParameter("corr"));
            usu.setPass(request.getParameter("pwd"));
            usu.setNotar(request.getParameter("NoTar"));
            usu.setMmyy(request.getParameter("mmyy"));
            usu.setCvc(request.getParameter("cvv"));
            usu.setNombre(request.getParameter("nom"));
            usu.setApellido(request.getParameter("apell"));
            usu.setCalle(request.getParameter("direccion"));
            usu.setCiudad(request.getParameter("city"));
            usu.setEstado(request.getParameter("state"));
            usu.setCp(request.getParameter("codigop"));
            
            DAO_Usuario dc = new DAO_Usuario();
            dc.create(usu);
            
            request.getRequestDispatcher("Apuesta.jsp").forward(request,response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CrearUsuarioServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

   

}
