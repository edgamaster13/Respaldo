package MODELO;

public class Usuario {

    private String id;
    private String correo;
    private String pass;
    private String notar;
    private String mmyy;
    private String cvc;
    private String nombre;
    private String apellido;
    private String calle;
    private String ciudad;
    private String estado;
    private String cp;
    

    public Usuario (String correo, String pass){
        this.correo = correo;
        this.pass = pass;
    }
    
    public Usuario(){
    }

    public Usuario(String id, String correo, String pass, String notar, String mmyy, String cvc, String nombre, String apellido, String calle, String ciudad, String estado, String cp) {
        this.id = id;
        this.correo = correo;
        this.pass = pass;
        this.notar = notar;
        this.mmyy = mmyy;
        this.cvc = cvc;
        this.nombre = nombre;
        this.apellido = apellido;
        this.calle = calle;
        this.ciudad = ciudad;
        this.estado = estado;
        this.cp = cp;
    }
    
    
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getNotar() {
        return notar;
    }

    public void setNotar(String notar) {
        this.notar = notar;
    }

    public String getMmyy() {
        return mmyy;
    }

    public void setMmyy(String mmyy) {
        this.mmyy = mmyy;
    }

    public String getCvc() {
        return cvc;
    }

    public void setCvc(String cvc) {
        this.cvc = cvc;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCp() {
        return cp;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }
    
    

}