/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELO;

/**
 *
 * @author Alejandro
 */
public class Apuesta {
    String id;
    String apuesta1;
    String apuesta2;

    public Apuesta() {
    }

    public Apuesta(String id, String apuesta1, String apuesta2) {
        this.id = id;
        this.apuesta1 = apuesta1;
        this.apuesta2 = apuesta2;
    }

    
    public Apuesta(String apuesta1, String apuesta2) {
        this.apuesta1 = apuesta1;
        this.apuesta2 = apuesta2;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApuesta1() {
        return apuesta1;
    }

    public void setApuesta1(String apuesta1) {
        this.apuesta1 = apuesta1;
    }

    public String getApuesta2() {
        return apuesta2;
    }

    public void setApuesta2(String apuesta2) {
        this.apuesta2 = apuesta2;
    }
    
    
    
}
