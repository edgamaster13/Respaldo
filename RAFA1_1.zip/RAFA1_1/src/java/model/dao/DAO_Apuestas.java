/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import MODELO.Apuesta;
import MODELO.Conexion2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

/**
 *
 * @author Alejandro
 */
public class DAO_Apuestas extends Conexion2 implements DAO<Apuesta>  {

    public DAO_Apuestas() throws ClassNotFoundException, SQLException {
        super("DbApuestas");
    }
    
    public Apuesta crearApuesta(String apu1, String apu2) throws SQLException{
        ResultSet rs = crear("SELECT * FROM apuestas");
        Apuesta a = null;
        if(rs.next()){
            a = new Apuesta();
            
            a.setApuesta1(rs.getString(1));
            a.setApuesta2(rs.getString(2));
            
        }
        
        close();
        
        return a;
    }

    
    @Override
    public void create(Apuesta ob) throws SQLException {
        crear("INSERT INTO apuestas (apuesta1,apuesta2) VALUES('"+ob.getApuesta1()+"','"+ob.getApuesta2()+"')");
    }

    
    public static LinkedList<Apuesta> getApuesta() throws SQLException {
        LinkedList<Apuesta> lista = new LinkedList<Apuesta>();
        try{
        Class.forName("org.apache.derby.jdbc.ClientDriver");
         Connection conexion = DriverManager.getConnection(
            "jdbc:derby://localhost:1527/DbApuestas");
        Statement st = conexion.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM apuestas where id = (SELECT max(id) FROM (apuestas))");
        
        Apuesta ap;
        while(rs.next()){
            ap = new Apuesta();
            
            ap.setId(rs.getString(1));
            ap.setApuesta1(rs.getString(2));
            ap.setApuesta2(rs.getString(3));
            
            lista.add(ap);
        }
        rs.close();
        st.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        return lista;
        
        
    }
    
    
    @Override
    public void update(Apuesta ob) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(String id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Apuesta> read(String txt) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Apuesta findByID(String id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Apuesta> read() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
