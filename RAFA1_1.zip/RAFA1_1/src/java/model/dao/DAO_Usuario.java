package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import MODELO.Conexion;
import MODELO.Usuario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.LinkedList;

public class DAO_Usuario extends Conexion implements DAO<Usuario>{

    public DAO_Usuario() throws ClassNotFoundException, SQLException {
        super("RAFA");
    }

    
    public Usuario getUsuario(String corre , String pas) throws SQLException{
        ResultSet rs = ejecutar("SELECT * FROM cliente WHERE (correo = '"+corre+"') AND (pass = '"+pas+"')");
        
        Usuario u = null;
        if(rs.next()){
            u = new Usuario();
            
            u.setId(rs.getString(1));
            u.setCorreo(rs.getString(2));
            u.setPass(rs.getString(3));
        }
        
        close();
        
        return u;
    }
    
    public Usuario crearUsuario(String correo, String pass, String notar, String mmyy, String cvc, String nombre, String apellido, String calle, String ciudad, String estado, String cp) throws SQLException{
        ResultSet rs = crear("SELECT * FROM cliente");
        Usuario u = null;
        if(rs.next()){
            u = new Usuario();
            
            u.setId(rs.getString(1));
            u.setCorreo(rs.getString(2));
            u.setPass(rs.getString(3));
            u.setNotar(rs.getString(4));
            u.setMmyy(rs.getString(5));
            u.setCvc(rs.getString(6));
            u.setNombre(rs.getString(7));
            u.setApellido(rs.getString(8));
            u.setCalle(rs.getString(9));
            u.setCiudad(rs.getString(10));
            u.setEstado(rs.getString(11));
            u.setCp(rs.getString(12));
            
        }
        
        close();
        
        return u;
    }
      public static LinkedList<Usuario> getUsuario() throws SQLException {
        LinkedList<Usuario> lista = new LinkedList<Usuario>();
        try{
        Class.forName("org.apache.derby.jdbc.ClientDriver");
         Connection conexion = DriverManager.getConnection(
            "jdbc:derby://localhost:1527/DbApuestas");
        Statement st = conexion.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM apuestas where id = (SELECT max(id) FROM (apuestas))");
        
        Usuario usu;
        while(rs.next()){
            usu = new Usuario();
            
            usu.setId(rs.getString(1));
            usu.setNombre(rs.getString(2));
            usu.setPass(rs.getString(3));
            usu.setNotar(rs.getString(4));
            usu.setMmyy(rs.getString(5));
            usu.setCvc(rs.getString(6));
            usu.setNombre(rs.getString(7));
            usu.setApellido(rs.getString(8));
            usu.setCalle(rs.getString(9));
            usu.setCiudad(rs.getString(10));
            usu.setEstado(rs.getString(11));
            usu.setCp(rs.getString(12));
            
            lista.add(usu);
        }
        rs.close();
        st.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        return lista;
        
        
    }
    
    @Override
    public void create(Usuario usu) throws SQLException {
        crear("INSERT INTO cliente VALUES(NULL, '"+usu.getCorreo()+"','"+usu.getPass()+"','"+usu.getNotar()+"','"+usu.getMmyy()+"','"+usu.getCvc()+"','"+usu.getNombre()+"','"+usu.getApellido()+"','"+usu.getCalle()+"','"+usu.getCiudad()+"','"+usu.getEstado()+"','"+usu.getCp()+"')");
        
    }

    @Override
    public List<Usuario> read() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Usuario ob) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(String id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Usuario> read(String txt) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Usuario findByID(String id) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
